package com.example.lost.pizza;
import android.icu.text.NumberFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
     int numberOfPizza=0;
     int numberOfPizza2=0;
    int numberOfPizza3=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private void display(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }
    private void display2(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view2);
        quantityTextView.setText("" + number);
    }
    private void display3(int number) {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view3);
        quantityTextView.setText("" + number);
    }
    /**
     * This method displays the given text on the screen.
     */
    public void increase(View view) {
        numberOfPizza = numberOfPizza + 1;
        display(numberOfPizza);


    }
    public void increase2(View view) {
        numberOfPizza2 = numberOfPizza2 + 1;
        display2(numberOfPizza2);
    }
    public void increase3(View view) {
        numberOfPizza3 = numberOfPizza3 + 1;
        display3(numberOfPizza3);
    }
    public void decrease(View view) {
        numberOfPizza = numberOfPizza2 - 1;
        display2(numberOfPizza);

        if (numberOfPizza < 0) {
            numberOfPizza = 0;
            display(numberOfPizza);


        }
    }
    public void decrease2(View view) {
        numberOfPizza2 = numberOfPizza2 - 1;
        display(numberOfPizza2);

        if (numberOfPizza2 < 0) {
            numberOfPizza2 = 0;
            display(numberOfPizza2);


        }
    }

    public void decrease3(View view) {
        numberOfPizza3 = numberOfPizza3 - 1;
        display3(numberOfPizza3);

        if (numberOfPizza3 < 0) {
            numberOfPizza3 = 0;
            display3(numberOfPizza3);


        }
    }

}

